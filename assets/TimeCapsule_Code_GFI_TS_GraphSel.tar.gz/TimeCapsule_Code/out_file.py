import numpy as np
import pandas as pd
import os
import sys
Dir = 'Simulation/Output/'





results_lowD_random = pd.DataFrame( np.zeros((18,5)), 
columns=['oracle_4p_120n','EAS_4p_120n','Han_LP_4p_120n','lasso_4p_120n',
				 'enet_4p_120n'],
index=['L2', '',
			 'LF', '',
			 'est err', '',
			 'active comp', '',
			 'FPR', '',
			 'FNR', '',
			 'prob truth', '',
			 'prop correct',
		   'min_eig_cov', '',
		 	 'cond2_satisfied'])

for file_name in [ 'oracle_', 'EAS_', 'Han_LP_', 'lasso_', 'enet_']:
	if os.path.isfile(Dir+'results_'+file_name+'random_4p_120n.pickle') == True:
		hold = pd.read_pickle(Dir+'results_'+file_name+'random_4p_120n.pickle')
		results_lowD_random[file_name+'4p_120n'] = hold

results_lowD_random.to_csv('Tables/pattern_lowD_random_results.csv', sep='&' )





for coef_pattern in [ 'band', 'cluster', 'hub', 'random', 'scale-free']:
	
	results = pd.DataFrame( np.zeros((18,10)), 
	columns=['oracle_10p_20n','EAS_10p_20n','Han_LP_10p_20n','lasso_10p_20n',
					 'enet_10p_20n',
	         'oracle_30p_180n','EAS_30p_180n','Han_LP_30p_180n','lasso_30p_180n',
					 'enet_30p_180n'],
	index=['L2', '',
				 'LF', '',
				 'est err', '',
				 'active comp', '',
				 'FPR', '',
				 'FNR', '',
				 'prob truth', '',
				 'prop correct',
			   'min_eig_cov', '',
			 	 'cond2_satisfied'])
		   
	for p, n in [ (10,20), (30,180)]: 
		for file_name in [ 'oracle_', 'EAS_', 'Han_LP_', 'lasso_', 'enet_']:
		
			if os.path.isfile(Dir+'results_'+file_name+coef_pattern+'_'+str(p)+
			                                       'p_'+str(n)+'n'+'.pickle') == True:
				
				hold = pd.read_pickle(Dir+'results_'+file_name+coef_pattern+
				                                   '_'+str(p)+'p_'+str(n)+'n'+'.pickle')
				
				results[file_name+str(p)+'p_'+str(n)+'n'] = hold
	
	if coef_pattern == 'band':
		results.to_csv('Tables/pattern_band_results.csv', sep='&' )
		
	if coef_pattern == 'cluster':
		results.to_csv('Tables/pattern_cluster_results.csv', sep='&' )
	
	if coef_pattern == 'hub':
		results.to_csv('Tables/pattern_hub_results.csv', sep='&' )
		
	if coef_pattern == 'random':
		results.to_csv('Tables/pattern_random_results.csv', sep='&' )
		
	if coef_pattern == 'scale-free':
		results.to_csv('Tables/pattern_scalefree_results.csv', sep='&' )




