
import numpy as np
import pandas as pd
import scipy.linalg as linalg
import matplotlib.pyplot as pyplot
import pygraphviz as pgvis

Dir_in = 'ClusterOut_real_data/'
Dir_out = '../Plots/'

for t, time_period in enumerate([ '1', '2']):
	
	stocks = pd.read_csv(Dir_in+'stocks_'+time_period+'.csv')
	n, p = stocks.shape
	scrY = np.transpose(stocks.values)[:,1:n]
	
	E_Omega = linalg.block_diag( scrY @ np.transpose(scrY) /n, np.eye(p))
	min_eig_cov = np.sqrt(n) * min(linalg.eigvalsh(E_Omega))
	print( 'left side of Condition 1 = ', min_eig_cov)
	

	# Compute inclusion proportions for each component of A ---------------------
	output = pd.read_pickle(Dir_in+'EAS_stocks_'+time_period+'.pickle')
	A_InclProp = 0
	for k in range(output['postSample'].shape[0]):
	
		G = output['postSample'][k,:].astype(bool)
		prob_G = output['postProbs'][k]
		temp = G * prob_G
		A_InclProp = A_InclProp + temp.reshape((p,p), order='F')
	
	index = (A_InclProp > 0)
	A_InclProp = pd.DataFrame( A_InclProp*index, stocks.columns, stocks.columns)
	# ---------------------------------------------------------------------------

	print(np.round( A_InclProp, 4))
	title = [ 'Time period: 1995-2006', 'Time period: 2010-2018']
	G = pgvis.AGraph( directed=True, label=title[t], labelloc='t')
	for ind_j, j in enumerate(A_InclProp.columns):
		G.add_node(j)

		for k in A_InclProp.columns:
			weight = np.round( A_InclProp[j][k], 2) * (A_InclProp[j][k] > .05)
			G.add_edge( j, k, penwidth=weight*5, arrowsize=('' if weight>0 else 0),
			            label=(weight if weight>0 else ''))


	G.node_attr.update( style="filled", color='#FF634790')
	G.edge_attr.update( width=5, color='#00FF7F90')
	G.layout('circo')
	G.draw(Dir_out+'directed_graph_'+time_period+'.pdf')