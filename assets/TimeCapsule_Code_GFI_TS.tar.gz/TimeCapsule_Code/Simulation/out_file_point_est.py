# This is a python script file which requires Python 3 to run
# To run from command line... 
# $ python out_file_point_est.py coef_pattern p n num_data_sets file_name Dir


import numpy as np
import pandas as pd
import scipy.linalg as linalg
import scipy.sparse as sparse
import scipy.sparse.linalg as splinalg
import os
import sys

coef_pattern = sys.argv[1]
p = int(sys.argv[2])
n = int(sys.argv[3])
num_data_sets = int(sys.argv[4])
# file_name options: 'lasso_', 'enet_', 'Han_LP_'
file_name = sys.argv[5] 
Dir = sys.argv[6]



true_model_size = np.zeros(num_data_sets)
MAP_model_size = np.zeros(num_data_sets)

fpr = np.zeros(num_data_sets)
fnr = np.zeros(num_data_sets)

prop_MAP_eq_truth = np.zeros(num_data_sets)
post_prob_truth = np.zeros(num_data_sets)

l2_error = np.zeros(num_data_sets)
lF_error = np.zeros(num_data_sets)
est_error = np.zeros(num_data_sets)

l2_error_oracle = np.zeros(num_data_sets)
lF_error_oracle = np.zeros(num_data_sets)
est_error_oracle = np.zeros(num_data_sets)



count = 0
for seed in range(num_data_sets):
	if (os.path.isfile( Dir+file_name+coef_pattern+'_'+str(p)+'p_'+str(n)+
			                                       'n_'+str(seed+1)+'.csv' ) == True):
		
		
		data = np.loadtxt(Dir+'data_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+
		                                          str(seed+1)+'.csv', delimiter=',')
		
		# True data generating model information ------------------------------
		true_par = pd.read_pickle(Dir+'true_par_'+coef_pattern+'_'+str(p)+'p_'+
		                                                      str(seed+1)+'.pickle')
		A = true_par['A'].toarray()
		Sigma = true_par['Sigma']
		
		G_true = np.zeros(p**2,dtype=bool)
		G_true[abs(A).flatten('F') > 0] = True
		
		G_true_index = np.where(abs(A).flatten('F') > 0)[0]
		# ---------------------------------------------------------------------
		
		
		# Identify the MAP model
		A_hat = np.loadtxt(Dir+file_name+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+
		                                           str(seed+1)+'.csv',delimiter=',')

		G_map = np.zeros(p**2,dtype=bool)
		G_map[abs(A_hat).flatten('F') > 0] = True
		# ---------------------------------------------------------------------
		
		
		# Locate the MAP model, and determine if it is the same as the true 
		# model 
		if np.array_equal(G_map, G_true) == True:
			prop_MAP_eq_truth[seed] = 1
		# ---------------------------------------------------------------------
		
		
		# Compute the FNR and FPR ---------------------------------------------
		true_model_size[seed] = sum(G_true)
		MAP_model_size[seed] = sum(G_map)
		
		# Compute/record the false negative rate - proportion of truly active 
		# components not selected active
		fnr[seed] = sum(G_map[G_true_index]==False) / sum(G_true)
		
		# Compute/record the false positive rate - proportion of truly inactive 
		# components selected active
		fpr[seed] = sum(G_map[list(set(np.arange(0,p**2)) - 
		                                 set(G_true_index))]) / (p**2 - sum(G_true))
		# ---------------------------------------------------------------------
		
		
		# Compute the prediction error and estimation error statistics, using 
		# the MAP model 
		# Testing data
		scrY_test = data[:,n:(2*n)]
		scrX_test = data[:,(n-1):(2*n-1)]
		
		# Comute l2_error, lF_error, and est_error for MAP model --------------		
		# Calculate the out-of-sample prediction error and the white noise 
		# covariance estimator
		pred_error = scrY_test - A_hat @ scrX_test
		Sigma_hat = pred_error @ np.transpose(pred_error) /n
		
		# Compute/record the spectral and Frobenius norms of the white noise 
		# covariance estimator, and the Frobenius norm of the estimation error 
		# as a ratio of the Frobenius norm of the true coefficient matrix
		l2_error[seed] = max(abs( linalg.svd( Sigma_hat, compute_uv=False) ))
		lF_error[seed] = np.sum(np.diag( Sigma_hat ))**.5
		est_error[seed] = ( np.trace( (A_hat - A) @ 
		   np.transpose(A_hat - A) )**.5 / np.trace( A @ np.transpose(A) )**.5 ) 
		# = ||A_hat - A||_F / ||A||_F
		
		count = count +1


print('count = ', count)
if count < 100:
	print(file_name+' pattern = '+coef_pattern+' n = '+str(n)+' p = '+str(p))

results = pd.Series( [str(np.round(np.mean(l2_error),2)),
											'('+str(np.round(np.std(l2_error),2))+')',
								      str(np.round(np.mean(lF_error),2)),
											'('+str(np.round(np.std(lF_error),2))+')',
										  str(np.round(np.mean(est_error),2)), 
											'('+str(np.round(np.std(est_error),2))+')',
										  str(np.round(np.mean(MAP_model_size),2)),
											'('+str(np.round(np.std(MAP_model_size),2))+')',
										  str(np.round(np.mean(fpr),2)), 
											'('+str(np.round(np.std(fpr),2))+')',
										  str(np.round(np.mean(fnr),2)), 
											'('+str(np.round(np.std(fnr),2))+')',
										  str(np.round(np.mean(post_prob_truth),2)), 
											'('+str(np.round(np.std(post_prob_truth),2))+')',
										  str(np.round(np.mean(prop_MAP_eq_truth),2)),
											None, None,
											None], 
										  index=['L2', '',
														 'LF', '',
														 'est err', '',
														 'active comp', '',
														 'FPR', '',
														 'FNR', '',
														 'prob truth', '',
														 'prop correct',
													   'min_eig_cov', '',
													 	 'cond2_satisfied'])


results.to_pickle(Dir+'results_'+file_name+coef_pattern+'_'+str(p)+'p_'+str(n)+
                                                                  'n'+'.pickle')
				  
				  
				  
				  
				  
				  