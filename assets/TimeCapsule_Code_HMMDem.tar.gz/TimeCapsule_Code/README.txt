This directory organizes the code used to produce the results of the paper.  

Please contact Jonathan Williams at williams.jonathan1@mayo.edu for any help or questions.


####################

‘Transitions_heat_movie.mp4’:

A movie to visualize the evolution of the transition rates in the state space over all 
integer ages from 50-90.

####################

‘Real_data/‘: 

A directory containing script files which produce the results for the actual Mayo Clinic 
Study of Aging (MCSA) data section of the paper.  Note that due to HIPAA restrictions, 
only a synthetic data set which resembles the real data set is provided.

####################

‘Simulation_dementia_data/’:

A directory containing script files which produce the results for the simulated MCSA 
data section of the paper.

####################

’Simulation_CAV_data/’:

A directory containing script files which produce the results for the simulated CAV data 
(from the ‘msm’ R package) section of the paper.

####################

‘hmm_1.1-6.tar.gz’:

Code containing the ‘hmm()’ function written to estimate the hidden Markov model.  Note 
that the ‘hmm()’ function does all of the likelihood computations, but makes a call to 
‘mcmcRoutine.r’ or ‘mcmcRoutine_cav.r’ for the MCMC routine (see within theprevious three 
directories for the MCMC routine script files).  To install, run the following command in 
a terminal:

R CMD INSTALL hmm_1.1-6.tar.gz