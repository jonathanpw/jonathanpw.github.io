This directory organizes the code used to produce the results of the paper.  

Please contact Jonathan Williams at jpwill@live.unc.edu for any help or questions.

NOTE: This code/paper was a part of my master’s thesis, so I didn’t yet have the best practices for organizing my code.  And the computations are probably not the most 
efficient.


####################

'MainLME.r':

This file contains code for estimating a linear mixed effects model without 
penalization.

####################

'MainPLME.r':

This file contains code for estimating a linear mixed effects model using the 
penalized estimation procedure described in the paper.

####################

'MainResults.r':

This file contains code for producing the tables presented in the paper.

####################

'MainSetup.r':

This file contains code for generating data from a synthetic linear mixed effect 
model.

####################

'MainSimulation.r':

This file is used to perform the simulations described in the paper.


