This directory organizes the code used to produce the results for the simulated MCSA data.  

Please contact Jonathan Williams at williams.jonathan1@mayo.edu for any help or questions.


####################

‘mcmcRoutine.r’:

This script file contains the code for our MCMC algorithm.

####################

‘RunFile.r’:

This script file contains the code for specifying the hidden Markov model (HMM) state 
space, parameters, response functions, the prior means and standard deviations, and 
running our MCMC algorithm.  This file is executed for random generator seeds 1-50, but
the results will vary slightly for the real MCSA data set and 'synthetic_MCSA_data.rda'.

####################

‘Simulate.r’:

This script file contains the code for generating the synthetic data, resembling the real 
MCSA data set, which are used in the simulation study.

####################

‘synthetic_MCSA_data.rda’:

This data file has been simulated from a modified version of the script file 'Simulate.r' 
to closely resemble the real MCSA data set.  The real MCSA data set is not provided due 
to HIPAA restrictions.  This data set is needed for generating further synthetic data sets
to perform the simulation study.

####################

‘OutFile_sim.r’:

This script file contains the code to produce the MCMC trace plots, histograms, and box
plots for the HMM parameters corresponding to the synthetic MCSA data sets.