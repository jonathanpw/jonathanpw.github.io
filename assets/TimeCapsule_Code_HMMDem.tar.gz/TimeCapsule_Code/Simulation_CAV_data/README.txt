This directory organizes the code used to produce the results for the simulated CAV data.  

Please contact Jonathan Williams at williams.jonathan1@mayo.edu for any help or questions.


####################

‘mcmcRoutine_cav.r’:

This script file contains the code for our MCMC algorithm.

####################

‘RunFile_cav.r’:

This script file contains the code for specifying the hidden Markov model (HMM) state 
space, parameters, response functions, the prior means and standard deviations, and 
running the estimation procedures.  This file is executed for random generator seeds 
1-100.

####################

‘Simulate_cav.r’:

This script file contains the code for generating the synthetic data, resembling the 
CAV data set from the 'msm' R package, which are used in the simulation study.

####################

‘useData.rda’:

This data file is a modified version of the CAV data set from the 'msm' R package.  It 
has been generated from the script file 'DataFormat_cav.r'.  It is used in the file 
'Simulate_cav.r' to generate synthetic data sets for the CAV simulation study.

####################

‘DataFormat_cav.r’:

This script file generates the data set 'useData.rda'.

####################

‘OutFile_boxplot_cav.r’:

This script file contains the code to produce the box plots for the HMM parameters 
corresponding to the synthetic CAV data sets.