This directory organizes the code used to produce the results for the real MCSA data set.  

Please contact Jonathan Williams at williams.jonathan1@mayo.edu for any help or questions.


####################

‘mcmcRoutine.r’:

This script file contains the code for our MCMC algorithm.

####################

‘RunFile.r’:

This script file contains the code for specifying the hidden Markov model (HMM) state 
space, parameters, response functions, the prior means and standard deviations, and 
running our MCMC algorithm.  This file is executed for random generator seeds 1-10, but
the results will vary slightly for the real MCSA data set and 'synthetic_MCSA_data.rda'.

####################

‘synthetic_MCSA_data.rda’:

This data file has been simulated from a modified version of the script file 'Simulate.r' 
(located in the directory '../Simulation_dementia_data/') to closely resemble the real 
MCSA data set.  The real MCSA data set is not provided due to HIPAA restrictions.

####################

‘OutFile.r’:

This script file contains the code to produce the MCMC trace plots and histograms for the 
HMM parameters corresponding to the real MCSA data set.

####################

‘OutFile_figures.r’:

This script file contains the code to produce all plots corresponding to the real MCSA 
data set, other than the MCMC trace plots and histograms.