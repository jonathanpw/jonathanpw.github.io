# This is a python script file which requires Python 3 to run
# To run from command line... 
# $ python simple_example.py 

from routine_EAS_VAR1 import *
import matplotlib.pyplot as pyplot
import pygraphviz as pgvis

np.random.seed(1)


# Generate the 'true' coefficent matrix and contemporaneous covariance matrix
n = 70 *2
p = 2
A = np.array([[.6,.05],
              [.55,.3]])
Sigma = np.diag(np.ones(p)) 

print( '||A|| = ', max(linalg.svd( A, compute_uv=False)))

# Generate VAR(1) model
scrY = np.zeros((p,n))
scrX = np.zeros((p,n))
scrU = np.transpose(np.random.multivariate_normal( np.zeros(p), Sigma, size=n)) 
for t in range(n):
	scrY[:,t] = A @ scrX[:,t] + scrU[:,t]
	if t < n-1:
		scrX[:,t+1] = scrY[:,t]

n = int(n/2)
scrY_test = scrY[:,n:(2*n)]
scrX_test = scrX[:,n:(2*n)]

scrY = scrY[:,0:n]
scrX = scrX[:,0:n]



steps = 3000
burnin = 2000
N = 3


# -----------------------------------------------------------------------------
# Run the epsilon-admissible subsets (EAS) mcmc algorithm
# -----------------------------------------------------------------------------
output = EAS_VAR( scrY, scrX, steps, burnin, N=N)
print(output['postSample'])
print('GF probabilities = ',output['postProbs'])


Y = ( scrY[:,].flatten('F') ).reshape((n*p,1))
vecX = ( scrX[:,].flatten('F') ).reshape((n*p,1))
scrZ = sparse.csr_matrix(np.kron( np.transpose(scrX), np.eye(p)))

		
# Compute inclusion proportions for each component of A ---------------------
A_InclProp = 0
l2_errors = []
for k in range(output['postSample'].shape[0]):
	G = output['postSample'][k,:].astype(bool)
	
	# Calculate the out-of-sample prediction erros for each G
	vecA_hat = (splinalg.inv( np.transpose(scrZ[:,G]) @ scrZ[:,G] ) @
					                            np.transpose(scrZ[:,G]) @ Y).flatten()
	temp = np.zeros(p**2)
	temp[G] = vecA_hat
	A_hat = temp.reshape((p,p), order='F')
	pred_error = scrY_test - A_hat @ scrX_test
	Sigma_hat = pred_error @ np.transpose(pred_error) /n
	l2_errors.append(max(abs( linalg.svd( Sigma_hat, compute_uv=False) )))
	
	
	prob_G = output['postProbs'][k]
	temp = G * prob_G
	A_InclProp = A_InclProp + temp.reshape((p,p), order='F')
index = (A_InclProp > 0)
A_InclProp = pd.DataFrame( A_InclProp*index,
                           ['node 1', 'node 2'], ['node 1', 'node 2'])
# ---------------------------------------------------------------------------

print('l2_errors = ', np.round(l2_errors,4))

G = pgvis.AGraph( directed=True, 
                  label='Marginal inclusion probabilities', labelloc='t')
for ind_j, j in enumerate(A_InclProp.columns):
	G.add_node(j)
	
	for k in A_InclProp.columns:
		weight = np.round( A_InclProp[j][k], 3)
		G.add_edge( j, k, penwidth=weight*2, arrowsize=('' if weight>0 else 0),
		            label=(weight if weight>0 else ''))

G.node_attr.update( style="filled", color='#FF634790')
G.edge_attr.update( width=5, color='#00FF7F90')
G.layout('circo')
G.draw('simple_example.pdf')



