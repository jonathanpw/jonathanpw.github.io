# This is a python script file which requires Python 3 to run
# To run from command line... 
# $ python run_file_EAS.py time_period steps burnin N

from routine_EAS_VAR1 import *
import sys

seed = 1
np.random.seed(int(seed))
time_period = sys.argv[1]  # time_period options: 1, 2
steps = int(sys.argv[2])
burnin = int(sys.argv[3])
N = int(sys.argv[4])

data = np.loadtxt( 'stocks_'+time_period+'.csv', delimiter=',', skiprows=1)
data = np.transpose(data)
p, n = data.shape
scrY = data[:,1:n]
scrX = data[:,0:(n-1)]


# -----------------------------------------------------------------------------
# Run the epsilon-admissible subsets (EAS) mcmc algorithm
# -----------------------------------------------------------------------------
Output = EAS_VAR( scrY, scrX, steps, burnin, N=N)

Output.to_pickle( 'EAS_stocks_'+time_period+'.pickle')
# -----------------------------------------------------------------------------