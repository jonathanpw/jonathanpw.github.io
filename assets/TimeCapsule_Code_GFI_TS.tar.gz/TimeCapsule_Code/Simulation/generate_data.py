# To run from command line... 
# $ python generate_data.py seed coef_pattern p n Dir

import numpy as np
import pandas as pd
import scipy.linalg as linalg
import scipy.sparse as sparse
import sys


# -----------------------------------------------------------------------------
# Function to generate random VAR(1) coefficient matrices of five different 
# patterns.
# -----------------------------------------------------------------------------
def generate_A( pattern, p, prob_active, p_block):
	
	# Construct an empty sparse matrix
	# Note that sparse.lil_matrix is efficient for constructin sparse matrices 
  # incremetally 
	A = sparse.lil_matrix((p,p))
	
	# All components on the first upper and lower diagonals are active
	if pattern=='band':
		for i in range(p): 
			signal = 3*(-1)**(np.random.uniform(0,1)<.5)
			if i < p-1: A[i,i+1] = np.random.normal(0,1) + signal
			if i > 0: A[i,i-1] = np.random.normal(0,1) + signal
	
	# Sparse block diagonal clutsers are active
	elif pattern=='cluster':
		if p % p_block != 0:
			print('USER ERROR: p is not a multiple of the number of blocks')
			exit()
		for i in range(p):  
			block_num = int(i/p_block)
			for j in range( block_num*p_block, block_num*p_block+p_block):  
				if np.random.uniform(0,1) < prob_active:  
					signal = 3*(-1)**(np.random.uniform(0,1)<.5)
					A[i,j] = np.random.normal(0,1) + signal
	
	# The first row and column of diagonal blocks are active
	elif pattern=='hub':
		if p % p_block != 0:
			print('USER ERROR: p is not a multiple of the number of blocks')
			exit()
		for i in range(p):
			if np.mod( i, p_block)==0:  
				signal = 3*(-1)**(np.random.uniform(0,1, size=p_block)<.5)
				A[i,range(i,i+p_block)] = np.random.normal(0,1,p_block) + signal
			else:
				block_num = int(i/p_block)
				signal = 3*(-1)**(np.random.uniform(0,1)<.5)
				A[i,block_num*p_block] = np.random.normal(0,1) + signal
	
	# Sparse active components throughout
	elif pattern=='random':
		for i in range(p):  
			for j in range(p):  
				if np.random.uniform(0,1) < prob_active:  
					signal = 3*(-1)**(np.random.uniform(0,1)<.5)
					A[i,j] = np.random.normal(0,1) + signal
	
	# The first row and column are active 
	elif pattern=='scale-free':
		signal = 3*(-1)**(np.random.uniform(0,1, size=p)<.5)
		A[0,:] = np.random.normal(0,1,p) + signal
		signal = 3*(-1)**(np.random.uniform(0,1, size=p)<.5)
		A[:,0] = np.random.normal(0,1,(p,1)) + signal.reshape((p,1))
	
	
	# All matrix patterns considered have active main diagonal components
	for i in range(p): 
		signal = 12*(-1)**(np.random.uniform(0,1)<.5)
		A[i,i] = np.random.normal(0,1) + signal
	# Compute the spectral norm of A to re-scale 
	norm_A = max(abs( linalg.svd( A.toarray(), compute_uv=False) ))
	
	return sparse.csr_matrix(.5 * A / norm_A)
# -----------------------------------------------------------------------------




seed = sys.argv[1]
np.random.seed(int(seed))
coef_pattern = sys.argv[2]
# coef_pattern options: 'band', 'cluster', 'hub', 'random', 'scale-free'
p = int(sys.argv[3])
n = int(sys.argv[4])*2
Dir = sys.argv[5]

# Generate the 'true' coefficent matrix and contemporaneous covariance matrix
A = generate_A( coef_pattern, p, .01, 5)
Sigma = np.diag(np.ones(p)) 

true_par = pd.Series([ A, Sigma], index=[ 'A', 'Sigma'])
true_par.to_pickle( Dir+'true_par_'+coef_pattern+'_'+str(p)+'p_'+str(seed)+
                                                                      '.pickle')


# Generate VAR(1) model
scrY = np.zeros((p,n))
scrX = np.zeros((p,n))
scrU = np.transpose(np.random.multivariate_normal( np.zeros(p), Sigma, size=n)) 
for t in range(n):
	scrY[:,t] = A @ scrX[:,t] + scrU[:,t]
	if t < n-1:
		scrX[:,t+1] = scrY[:,t]

n = int(n/2)
np.savetxt( Dir+'data_'+coef_pattern+'_'+str(p)+'p_'+str(n)+'n_'+seed+'.csv', 
                                              scrY, delimiter=',', newline='\n')

