# This script file contains Unix command line code to reproduce the results in the paper,
# ’A Bayesian Approach to Multi-State Hidden Markov Models: Application to Dementia Progression’.  
# Please contact Jonathan Williams at williams.jonathan1@mayo.edu for any help or questions.



####################
# ‘synthetic_MCSA_data.rda’ has been simulated from a modified version of the script file 'Simulate.r' 
# to closely resemble the real MCSA data set.  The real MCSA data set is not provided due to HIPAA restrictions.

# ‘Transitions_heat_movie.mp4’ is a movie to visualize the evolution of the transition rates in the state space
# over all integer ages from 50-90.
####################



####################
# To reproduce the real MCSA data results run:

R CMD INSTALL hmm_1.1-6.tar.gz

mkdir Real_data_output/
cp RunFile.r OutFile.r OutFile_figures.r mcmcRoutine.r synthetic_MCSA_data.rda Real_data_output/
cd Real_data_output/

for seed in {1..10}
do
Rscript RunFile.r $seed RealData Bayesian no_scale
done

Rscript OutFile.r ./ 10 no_scale
Rscript OutFile_figures.r ./ 10 no_scale
cd ../

# This code uses 30 threads in parallel.  The for loop above can be run in an embarrassingly parallel fashion.
# The code for each $seed may take about 3 days to run.
###################



###################
# To reproduce the sensitivity analysis for the real MCSA data results run:

R CMD INSTALL hmm_1.1-6.tar.gz

mkdir Sensitivity_test/
cp RunFile.r OutFile.r OutFile_figures.r mcmcRoutine.r synthetic_MCSA_data.rda Sensitivity_test/
cd Sensitivity_test/

for seed in {1..10}
do
Rscript RunFile.r $seed RealData Bayesian 10x_scale
done

Rscript OutFile.r ./ 10 10x_scale
Rscript OutFile_figures.r ./ 10 10x_scale
cd ../

# This code uses 30 threads in parallel.  The for loop above can be run in an embarrassingly parallel fashion.
# The code for each $seed may take about 3 days to run.
###################



###################
# To reproduce the synthetic MCSA simulation results run:

R CMD INSTALL hmm_1.1-6.tar.gz

mkdir Simulation_output/
cp RunFile.r Simulate.r OutFile_sim.r mcmcRoutine.r synthetic_MCSA_data.rda Simulation_output/
cd Simulation_output/

for seed in {1..50}
do
Rscript Simulate.r $seed
Rscript RunFile.r $seed Simulation Bayesian no_scale
done

Rscript OutFile_sim.r ./ 50
cd ../

# This code uses 30 threads in parallel.  The for loop above can be run in an embarrassingly parallel fashion.
# The code for each $seed may take about 2 days to run.
###################



###################
# To reproduce the CAV data simulation results run:

R CMD INSTALL hmm_1.1-6.tar.gz

mkdir CAV_sim/
cp RunFile_cav.r Simulate_cav.r OutFile_boxplot_cav.r mcmcRoutine_cav.r CAV_sim/
cd CAV_sim/

for seed in {1..100}
do
Rscript Simulate_cav.r $seed FALSE
Rscript RunFile_cav.r $seed
done

Rscript OutFile_boxplot_cav.r ./ 100 FALSE
cd ../


mkdir CAV_sim_population/
cp RunFile_cav.r Simulate_cav.r OutFile_boxplot_cav.r mcmcRoutine_cav.r CAV_sim_population/
cd CAV_sim_population/

for seed in {1..100}
do
Rscript Simulate_cav.r $seed TRUE
Rscript RunFile_cav.r $seed
done

Rscript OutFile_boxplot_cav.r ./ 100 TRUE
cd ../

# This code uses 8 threads in parallel.  The for loops above can each be run in an embarrassingly parallel fashion.
# The code for each $seed may take about 1 day to run.
###################
