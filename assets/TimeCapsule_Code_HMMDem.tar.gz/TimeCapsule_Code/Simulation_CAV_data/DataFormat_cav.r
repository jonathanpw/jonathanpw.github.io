
library(msm)

obstype_hmm <- rep(1,nrow(cav))
obstype_hmm[cav$state == 4] <- 2
obstype_hmm[!duplicated(cav$PTNUM)] <- 3

iyears <- floor(cav$years)

obstrue <- rep(0,nrow(cav))

hold <- cbind(cav,obstrue,obstype_hmm,iyears)
hold <- hold[,c('PTNUM','years','iyears','sex','state','obstrue','obstype_hmm')]



tempRow <- rep(0,ncol(hold))
names(tempRow) <- c('PTNUM','years','iyears','sex','state','obstrue','obstype_hmm')

num <- 1
useData_cav <- NULL
for(i in unique(hold$PTNUM)){
	
	Current <- NULL
	Subject <- hold[hold$PTNUM==i,,drop=FALSE]
	
	#------------------------------------
	censoredAges <- 0:max(Subject$years)
	for(t in censoredAges ){

		# If 't' corresponds to an observed age, then the next row will include the observed clinical visit data.
		if(t %in% Subject$years){	
			Current <- rbind( Current, Subject[Subject$iyears==floor(t),]) 
		} else{
		
			# Create a CENSORED row for each subject at each INTEGER year of years.
			tempRow['PTNUM'] <- i
			tempRow['years'] <- t 
			tempRow['iyears'] <- t
			tempRow['sex'] <- Subject$sex[1]
			tempRow['state'] <- 99
			tempRow['obstrue'] <- 1  
			tempRow['obstype_hmm'] <- 0
			
			Current <- rbind( Current, tempRow)
			
			# If 't' corresponds to an observed INTEGER years, then the subject was observed some time during this years.  According, the next row will include the observed clinical visit data.  Recall that integer years is simply the floor(years).
			if(t %in% Subject$iyears){ Current <- rbind( Current, Subject[Subject$iyears==t,]) }
		}

	}
	#------------------------------------
	
	useData_cav <- rbind( useData_cav, Current)
	print(num)
	num <- num+1
}
colnames(useData_cav) <- c('PTNUM','years','iyears','sex','state','obstrue','obstype_hmm')

#print(round(mean(useData_cav$years),0)) = 4
useData_cav$iyears <- useData_cav$iyears - round(mean(useData_cav$years),0)
useData_cav$years <- useData_cav$years - round(mean(useData_cav$years),0)				

rownames(useData_cav) <- NULL

save(useData_cav,file='useData.rda')