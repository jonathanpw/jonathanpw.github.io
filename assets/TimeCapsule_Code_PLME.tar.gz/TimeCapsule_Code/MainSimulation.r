LambdaMin = 0.11
LambdaMax = 0.36
XiMin = 0.05
XiMax = 0.25
RhoMin = 1
RhoMax = 1.5
increments = 6

Simulations = 200

PLMESimulationList = list(NULL)
SimulatedDataList = list(NULL)
LMESimulationList = list(NULL)
MaxLikSimulationList = list(NULL)

rinteger = floor(runif(1)*1000)
set.seed(rinteger)

OracleDataFE <- function(Data) {
	Data = Data[,(Beta != 0)]
}

OracleDataRE <- function(Data) {
	Data = Data[,(diag(D) != 0)]
}

for (K in 1:Simulations) {
	
	StoreSimulateLME = SimulateLME(nArray,sigma,Beta,D)
	SimulatedDataList[[K]] = StoreSimulateLME
	
	PLMESimulationList[[K]] = SearchPLME(StoreSimulateLME,a,LambdaMin,LambdaMax,XiMin,XiMax,RhoMin,RhoMax,
										 increments)
	
	StoreSimulateLME$Xlist = lapply(StoreSimulateLME$Xlist,OracleDataFE)
	StoreSimulateLME$p = sum(Beta != 0)
	StoreSimulateLME$Zlist = lapply(StoreSimulateLME$Zlist,OracleDataRE)
	StoreSimulateLME$qu = sum(diag(D) != 0)
	
	LMESimulationList[[K]] = LME(StoreSimulateLME)
	MaxLikSimulationList[[K]] = MLE(StoreSimulateLME)
	
	print(K)
}


LMEBetaMatrix = matrix(0,Simulations,p)
LMEDlist = list(NULL)
LMEblist = list(NULL)
LMESigmaSQArray = rep(0,Simulations)

MaxLikBetaMatrix = matrix(0,Simulations,p)
MaxLikDlist = list(NULL)
MaxLikblist = list(NULL)
MaxLikSigmaSQArray = rep(0,Simulations)

GCVBetaMatrix = matrix(0,Simulations,p)
GCVDlist = list(NULL)
GCVblist = list(NULL)
GCVSigmaSQArray = rep(0,Simulations)
GCVCountArray = rep(0,Simulations)

AICBetaMatrix = matrix(0,Simulations,p)
AICDlist = list(NULL)
AICblist = list(NULL)
AICSigmaSQArray = rep(0,Simulations)
AICCountArray = rep(0,Simulations)

BICBetaMatrix = matrix(0,Simulations,p)
BICDlist = list(NULL)
BICblist = list(NULL)
BICSigmaSQArray = rep(0,Simulations)
BICCountArray = rep(0,Simulations)

glassoGCVBetaMatrix = matrix(0,Simulations,p)
glassoGCVDlist = list(NULL)
glassoGCVblist = list(NULL)
glassoGCVSigmaSQArray = rep(0,Simulations)
glassoGCVCountArray = rep(0,Simulations)

glassoAICBetaMatrix = matrix(0,Simulations,p)
glassoAICDlist = list(NULL)
glassoAICblist = list(NULL)
glassoAICSigmaSQArray = rep(0,Simulations)
glassoAICCountArray = rep(0,Simulations)

glassoBICBetaMatrix = matrix(0,Simulations,p)
glassoBICDlist = list(NULL)
glassoBICblist = list(NULL)
glassoBICSigmaSQArray = rep(0,Simulations)
glassoBICCountArray = rep(0,Simulations)


EmptyD = matrix(0,qu,qu)
for (J in 1:Simulations) {

	CurrentList = PLMESimulationList[[J]]
	
	LMECurrentList = LMESimulationList[[J]]
	
	LMESigmaSQArray[J] = as.numeric(unlist(LMECurrentList$sigmaSQ_hat))
	EmptyD = matrix(0,qu,qu)
	EmptyD[(diag(D) != 0),(diag(D) != 0)] = matrix(unlist(LMECurrentList$D_hat),sum(diag(D) != 0),
	 											   sum(diag(D) != 0))
	LMEDlist[[J]] = EmptyD
	Emptyb = matrix(0,qu,m)
	Emptyb[(diag(D) != 0),] = matrix(unlist(LMECurrentList$bMat),sum(diag(D) != 0),m)
	LMEblist[[J]] = Emptyb
	LMEBetaMatrix[J,][(Beta != 0)] = matrix(unlist(LMECurrentList$Beta_hat),1,sum(Beta != 0))
	
	MaxLikCurrentList = MaxLikSimulationList[[J]]
	
	MaxLikSigmaSQArray[J] = as.numeric(unlist(MaxLikCurrentList$sigmaSQ_hat))
	EmptyD = matrix(0,qu,qu)
	EmptyD[(diag(D) != 0),(diag(D) != 0)] = matrix(unlist(MaxLikCurrentList$D_hat),sum(diag(D) != 0),
												   sum(diag(D) != 0))
	MaxLikDlist[[J]] = EmptyD
	Emptyb = matrix(0,qu,m)
	Emptyb[(diag(D) != 0),] = matrix(unlist(MaxLikCurrentList$bMat),sum(diag(D) != 0),m)
	MaxLikblist[[J]] = Emptyb
	MaxLikBetaMatrix[J,][(Beta != 0)] = matrix(unlist(MaxLikCurrentList$Beta_hat),1,sum(Beta != 0))
	
	GCVlist_NOglasso = CurrentList[[1]]
	
	GCVCountArray[J] = as.numeric(unlist(GCVlist_NOglasso$count))
	GCVSigmaSQArray[J] = as.numeric(unlist(GCVlist_NOglasso$sigmaSQ_hat))
	GCVDlist[[J]] = matrix(unlist(GCVlist_NOglasso$D_hat),qu,qu)
	GCVblist[[J]] = matrix(unlist(GCVlist_NOglasso$bMat),qu,m)
	GCVBetaMatrix[J,] = matrix(unlist(GCVlist_NOglasso$Beta_hat),1,p)
	
	AIClist_NOglasso = CurrentList[[2]]
	
	AICCountArray[J] = as.numeric(unlist(AIClist_NOglasso$count))
	AICSigmaSQArray[J] = as.numeric(unlist(AIClist_NOglasso$sigmaSQ_hat))
	AICDlist[[J]] = matrix(unlist(AIClist_NOglasso$D_hat),qu,qu)
	AICblist[[J]] = matrix(unlist(AIClist_NOglasso$bMat),qu,m)
	AICBetaMatrix[J,] = matrix(unlist(AIClist_NOglasso$Beta_hat),1,p)
	
	BIClist_NOglasso = CurrentList[[3]]
	
	BICCountArray[J] = as.numeric(unlist(BIClist_NOglasso$count))
	BICSigmaSQArray[J] = as.numeric(unlist(BIClist_NOglasso$sigmaSQ_hat))
	BICDlist[[J]] = matrix(unlist(BIClist_NOglasso$D_hat),qu,qu)
	BICblist[[J]] = matrix(unlist(BIClist_NOglasso$bMat),qu,m)
	BICBetaMatrix[J,] = matrix(unlist(BIClist_NOglasso$Beta_hat),1,p)
	
	GCVlist_glasso = CurrentList[[4]]
	
	glassoGCVCountArray[J] = as.numeric(unlist(GCVlist_glasso$count))
	glassoGCVSigmaSQArray[J] = as.numeric(unlist(GCVlist_glasso$sigmaSQ_hat))
	glassoGCVDlist[[J]] = matrix(unlist(GCVlist_glasso$D_hat),qu,qu)
	glassoGCVblist[[J]] = matrix(unlist(GCVlist_glasso$bMat),qu,m)
	glassoGCVBetaMatrix[J,] = matrix(unlist(GCVlist_glasso$Beta_hat),1,p)
	
	AIClist_glasso = CurrentList[[5]]
	
	glassoAICCountArray[J] = as.numeric(unlist(AIClist_glasso$count))
	glassoAICSigmaSQArray[J] = as.numeric(unlist(AIClist_glasso$sigmaSQ_hat))
	glassoAICDlist[[J]] = matrix(unlist(AIClist_glasso$D_hat),qu,qu)
	glassoAICblist[[J]] = matrix(unlist(AIClist_glasso$bMat),qu,m)
	glassoAICBetaMatrix[J,] = matrix(unlist(AIClist_glasso$Beta_hat),1,p)
	
	BIClist_glasso = CurrentList[[6]]
	
	glassoBICCountArray[J] = as.numeric(unlist(BIClist_glasso$count))
	glassoBICSigmaSQArray[J] = as.numeric(unlist(BIClist_glasso$sigmaSQ_hat))
	glassoBICDlist[[J]] = matrix(unlist(BIClist_glasso$D_hat),qu,qu)
	glassoBICblist[[J]] = matrix(unlist(BIClist_glasso$bMat),qu,m)
	glassoBICBetaMatrix[J,] = matrix(unlist(BIClist_glasso$Beta_hat),1,p)
}
